class RestaurantsController < ApplicationController
  before_action :set_restaurant, only: %i[ show update destroy dishes ]

  def new
    @restaurant = Restaurant.new
  end

  # GET /restaurants
  def index
    @restaurants = Restaurant.includes(:city)

    render json: @restaurants
  end

  # GET /restaurants/1
  def show
    render json: @restaurant
  end

  # POST /restaurants
  def create
    respond_to do |format|
      format.json do
        @restaurant = Restaurant.new(restaurant_params)

        if @restaurant.save
          render json: @restaurant, status: :created, location: @restaurant
        else
          render json: @restaurant.errors, status: :unprocessable_content
        end
      end

      format.html do
        attributes = restaurant_form_params
        city_name = attributes.delete(:city_name).to_s.strip
        state = attributes.delete(:state).to_s.strip
        country = attributes.delete(:country).to_s.strip

        if city_name.blank? || state.blank? || country.blank?
          @restaurant = Restaurant.new(name: attributes[:name])
          @restaurant.errors.add(:base, "Select a restaurant from the Google Places suggestions.")
          render :new, status: :unprocessable_entity
          next
        end

        city = City.find_or_initialize_by(name: city_name.titleize)
        if city.new_record?
          city.update!(state: state, country: country)
        end

        @restaurant = Restaurant.find_or_initialize_by(name: attributes[:name].to_s.strip, city: city)
        if @restaurant.save
          redirect_to new_dish_path, notice: "Restaurant added. You can now write a dish review."
        else
          render :new, status: :unprocessable_entity
        end
      end
    end
  end

  # PATCH/PUT /restaurants/1
  def update
    if @restaurant.update(restaurant_params)
      render json: @restaurant
    else
      render json: @restaurant.errors, status: :unprocessable_content
    end
  end

  # DELETE /restaurants/1
  def destroy
    @restaurant.destroy!
  end

  def dishes
    @restaurant = Restaurant.find(params[:id].to_i)
    @dishes = load_dishes(@restaurant.dishes)
    @cities = City.all
    render "dishes/index"
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_restaurant
      @restaurant = Restaurant.find(params.expect(:id))
    end

    # Only allow a list of trusted parameters through.
    def restaurant_params
      params.expect(restaurant: [ :name, :city_id ])
    end

    def restaurant_form_params
      params.expect(restaurant: [ :name, :city_name, :state, :country ])
    end
end
