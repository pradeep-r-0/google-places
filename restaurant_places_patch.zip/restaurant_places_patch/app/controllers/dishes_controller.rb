class DishesController < ApplicationController
  before_action :require_login, except: %i[index show]
  before_action :set_dish, only: %i[show edit update destroy]
  before_action :check_ownership, only: %i[update destroy edit]

  # GET /dishes
  def index
    load_dishes(Dish.all, paginate: false)
    @cities = City.approved.order(:name)

    if params[:city_id].present?
      @selected_city = @cities.find(params[:city_id])
      @dishes = @dishes.where(restaurants: { city_id: @selected_city.id })
    end

    if params[:dish_name].present?
        @dishes = @dishes.where("dishes.name ILIKE ?", "%#{params[:dish_name]}%")
    end

    if params[:restaurant_name].present?
        @dishes = @dishes.joins(:restaurant).where("restaurants.name ILIKE ?", "%#{params[:restaurant_name]}%")
    end

    @dishes = @dishes.page(params[:page]).per(10)

    respond_to do |format|
      format.html # renders views/dishes/index.html.erb
      format.json { render json: @dishes }
    end
  end

  # GET /dishes/1
  def show
    respond_to do |format|
      format.json { render json: @dish }
      format.html
    end
  end

  def edit
  end

  def new
    @dish = Dish.new
    load_restaurants
  end
  # POST /dishes
  def create
    attributes = dish_params
    restaurant = Restaurant.find(attributes.delete(:restaurant_id))
    @dish = restaurant.dishes.new(attributes)
    @dish.user = current_user
    if @dish.save
      redirect_to @dish, notice: "Dish created successfully."
    else
      load_restaurants
      render :new
    end
  end

  # PATCH/PUT /dishes/1
  def update
    if @dish.update(dish_params)
      flash[:notice] = "Dish review was successfully updated."
      redirect_to @dish
    else
      flash[:alert] = "Failed to update the dish review."
      render :edit, status: :unprocessable_entity
    end
  end

  # DELETE /dishes/1
  def destroy
    @dish.destroy!
  end

  def my_reviews
    load_dishes(current_user.dishes)
    @cities = City.approved
    render "index"
  end

  private
  # Use callbacks to share common setup or constraints between actions.

  def set_dish
    @dish ||= Dish.find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def dish_params
    params.require(:dish).permit(:name, :rating, :comments, :restaurant_id)
  end

  def load_restaurants
    @restaurants = Restaurant.includes(:city).order(:name)
  end

  def check_ownership
    return redirect_to(dishes_path, alert: "You are not authorized to access this dish.") if @dish.user != current_user
  end

end
