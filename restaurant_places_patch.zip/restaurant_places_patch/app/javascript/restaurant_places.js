function initializeRestaurantPlaces() {
  const input = document.getElementById("restaurant-name-input");
  if (!input || input.dataset.placesInitialized) return;

  if (!window.google?.maps?.places) {
    window.setTimeout(initializeRestaurantPlaces, 300);
    return;
  }

  input.dataset.placesInitialized = "true";
  const cityField = document.getElementById("restaurant-city-name");
  const stateField = document.getElementById("restaurant-state");
  const countryField = document.getElementById("restaurant-country");
  const form = input.closest("form");
  const autocomplete = new google.maps.places.Autocomplete(input, {
    types: ["establishment"],
    componentRestrictions: { country: "in" },
    fields: ["name", "address_components"]
  });

  let placeSelected = false;

  autocomplete.addListener("place_changed", () => {
    const place = autocomplete.getPlace();
    const component = (type) => place.address_components?.find((item) => item.types.includes(type))?.long_name || "";
    const city = component("locality") || component("administrative_area_level_2");
    const state = component("administrative_area_level_1");
    const country = component("country");

    if (!place.name || !city || !state || !country) return;

    input.value = place.name;
    cityField.value = city;
    stateField.value = state;
    countryField.value = country;
    placeSelected = true;
  });

  input.addEventListener("input", () => {
    placeSelected = false;
    cityField.value = "";
    stateField.value = "";
    countryField.value = "";
  });

  form?.addEventListener("submit", (event) => {
    if (!placeSelected) {
      event.preventDefault();
      alert("Please select a restaurant from the Google Places suggestions.");
      input.focus();
    }
  });
}

document.addEventListener("turbo:load", initializeRestaurantPlaces);