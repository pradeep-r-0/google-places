# Restaurant Google Places standalone form patch

This folder is an overlay package for the Rails app. Copy its `app/` tree into the project root, preserving paths.

## Included behavior

- Adds `/restaurants/new`, a standalone Google Places restaurant creation form.
- Stores restaurant name and city/state/country from the selected suggestion.
- Changes dish review creation to select a saved restaurant, with a link to add one.
- Loads the Google Maps Places API only on the restaurant creation page.

The existing `resources :restaurants` route already provides the `new` and `create` routes. Configure `GOOGLE_PLACES_API_KEY` in the Rails environment. JavaScript build outputs are included in `app/assets/builds`; rebuild with the project's asset build process if desired.
